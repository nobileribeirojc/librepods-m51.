# Continuação do código original LibrePods — Galaxy M51

## Proveniência

**Este pacote é o projeto LibrePods**, não o projeto independente `Pods-M51`.
A base foi recuperada do `LibrePods-M51-projeto-experimental.zip` existente, derivada de
LibrePods **v0.1.0-rc.4** (commit b8e9765), com modificações Android 12.
Licença original e notificações de copyright preservadas (AGPL v3).

## Alterações desta continuação (`m51-exp2`)

1. A tela inicial volta a ser a **interface original do LibrePods** (configurações, bateria,
   controles ANC/AACP existentes). A tela `m51_diagnostics` é apenas uma ferramenta extra.
2. A tela de diagnóstico BLE pode ser aberta pela interface original com ou sem conexão
   AACP, além de um item específico em Configurações.
3. A seleção de leituras BLE não fica travada ao atingir 30 endereços rotativos; as leituras
   caducam e são eliminadas após 60 segundos, com validade de bateria de até 15 segundos.
4. O scanner reporta situações concretas: Bluetooth desligado, scanner indisponível,
   falha de varredura, em vez de sinalizar sucesso sem iniciá-lo.
5. Android 12 exige na entrada só `BLUETOOTH_CONNECT`, `BLUETOOTH_SCAN` e localização
   precisa para este teste. Controle de chamadas passa a ser opcional, e a escuta
   telefônica só é registrada com `READ_PHONE_STATE` concedido.
6. Removidas permissões privilegiadas inutilizáveis de Android sem root e um segundo
   launcher inadvertido. O serviço Bluetooth do LibrePods deixou de ser exportado.
7. Um único `startService` por inicialização da composição; antes ocorria durante
   recomposições da interface.
8. Incluído workflow GitHub Actions para tentativa de compilação de `app-debug.apk`.

## Limitação técnica (ainda NÃO resolvida)

**Não há comprovação de que ANC/Transparência funcionem no SM-M515F Android 12 sem root.**
A conexão AACP clássica L2CAP (PSM 4097) continua sujeita à pilha Bluetooth do
Samsung Android 12. O acesso a anúncios BLE e leitura aproximada de bateria não
substitui esse canal. Não é tecnicamente honesto chamar esta entrega de APK
funcional no M51 antes de compilar e testar no aparelho.

## Compilação

Use JDK 17, Android SDK 35, wrapper Gradle contido em `android/`:

```sh
cd android
./gradlew :app:assembleDebug
```

O GitHub Actions incluído disponibiliza o `app-debug.apk` na execução com sucesso.
**Não instale arquivos APK previamente fornecidos pelo projeto independente `Pods-M51`**:
eles não representam estas modificações do código original do LibrePods.

## Passos do teste físico

1. Parear os AirPods Pro 3 e conceder Bluetooth + Localização no Android 12.
2. Abrir **LibrePods M51 (teste)** e acessar **Bateria BLE e diagnóstico**.
3. Abrir o estojo próximo do telefone, observar anúncios BLE, selecionar um anúncio
   recente e verificar se mostra bateria esquerda/direita/estojo.
4. Tentar controlar ANC na interface original, se houver conexão AACP. Se falhar,
   copiar o relatório do diagnóstico (sem MAC/IRK/pacotes brutos).
5. A causa exata da falha de L2CAP depende do teste real no M51.
