# LibrePods M51 v4 — como gerar o APK de teste

Este pacote é o código-fonte **original do LibrePods, modificado** para Android 12 (Galaxy M51). Não há APK pré-compilado neste ZIP.

## GitHub Actions (sem instalar compiladores no computador)

1. Crie um repositório GitHub, de preferência **privado**.
2. Envie o **conteúdo** desta pasta à raiz do repositório (a pasta `android/`, a pasta `.github/` e o restante devem ficar diretamente na raiz).
3. Abra a aba `Actions` e selecione **Gerar APK LibrePods M51 (Android 12)**.
4. Toque em **Run workflow** e aguarde o resultado.
5. Se a execução estiver verde, abra a execução, procure `Artifacts` e baixe **LibrePods-M51-v4-APK**.
6. Extraia o ZIP do artifact para obter **LibrePods-M51-v4-debug.apk** e instale-o no Android, autorizando a instalação para o aplicativo de arquivos ou navegador que estiver usando.

**Importante:** os controles ANC/Transparência dependem do canal Bluetooth L2CAP clássico dos AirPods; a compilação do APK não elimina a incompatibilidade potencial da pilha Bluetooth Android 12 do Galaxy M51. A bateria BLE e a janela também precisam ser verificadas no aparelho real. Este é um APK de testes, não uma versão final auditada.

## Compilar em um PC (alternativa)

Requisitos: JDK 17, Android SDK 35 e internet para baixar o Gradle/dependências.

```sh
cd android
./gradlew :app:assembleDebug
```

Arquivo esperado: `android/app/build/outputs/apk/debug/app-debug.apk`.

## Se a compilação falhar

Na página da execução do GitHub Actions, copie a primeira falha `e: ...` (Kotlin) ou `FAILURE: Build failed with an exception`, incluindo as linhas anteriores e seguintes. Isso permite corrigir erros reais de compilação antes de instalar.
