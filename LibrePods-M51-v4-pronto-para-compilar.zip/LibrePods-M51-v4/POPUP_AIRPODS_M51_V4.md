# LibrePods M51 – popup de bateria (continuação do projeto original)

Base: LibrePods v0.1.0-rc.4, commit b8e9765, com alterações M51 das versões experimentais anteriores. Licença GNU AGPL-3.0.

## O que entrou nesta versão

- **Popup original do LibrePods** refeito visualmente, com ilustração já distribuída no projeto, nome dos AirPods, porcentagens individuais de esquerdo, direito e estojo e indicação de carregamento.
- A arte atual é a ilustração de **AirPods Pro 2** já incluída no LibrePods, semelhante aos Pro 3; está identificada como ilustração, e não como foto exata dos Pro 3.
- O popup pode abrir por abertura de tampa detectada em BLE autenticado por IRK, sem depender do AACP; mantém o fluxo existente de AACP se ele estiver funcionando.
- Sem IRK: opção **experimental e desativada por padrão** em Configurações → `Janela de bateria ao abrir o estojo (M51)`. Aceita anúncios **públicos** de AirPods Pro 3 próximos, com RSSI >= -64 dBm, somente se há AirPods pareados no telefone. Tem intervalo mínimo de 60 s entre janelas para reduzir falsos positivos. **Não identifica criptograficamente o fone**: pode captar AirPods Pro 3 de outras pessoas muito próximas.
- Imediatamente após abrir, atualiza bateria a partir do anúncio BLE que disparou a janela; novos anúncios com o mesmo endereço aleatório podem atualizar a janela. Sem informação, mostra **—**, nunca inventa 0%.
- No diagnóstico M51 existe botão para pedir permissão de sobreposição e outro para visualizar a janela sem fabricar valores de bateria.
- Leitura pública normalmente em **passos de 10%**, sem prometer exatidão absoluta; para 1% pode ser necessário IRK/ENC extraídos de forma compatível. O estojo nem sempre informa bateria (por exemplo sem fones dentro).
- Mantido o código AACP/L2CAP existente do LibrePods, ainda sujeito à limitação Bluetooth do Samsung M51 Android 12 sem root. Esta versão não garante ANC/Transparência.

## Teste no aparelho

1. Instalar **um APK compilado e assinado** deste código-fonte (não confundir o ZIP com APK).
2. Conectar e parear os AirPods Pro 3 ao Samsung M51 no Bluetooth do Android.
3. Conceder permissões Bluetooth, Localização e permitir a execução em segundo plano conforme opções do Samsung.
4. Abrir o LibrePods → Configurações → ativar `Janela de bateria ao abrir o estojo (M51)`.
5. Abrir Diagnóstico M51 → `Autorizar janela sobre outros apps` → autorizar para o LibrePods.
6. Usar `Visualizar janela com a bateria disponível` para testar a interface. Ausência de bateria => —.
7. Com ambos os fones no estojo, aproximar o estojo do celular e abrir a tampa. Aguarde anúncios BLE.
8. Caso não abra, verificar permissões, se serviço e varredura BLE estão ativos, e diagnóstico. O dispositivo pode não emitir o formato esperado ou estar distante.

## Arquivos principais modificados

- `android/app/src/main/java/me/kavishdevar/librepods/utils/BLEManager.kt`
- `android/app/src/main/java/me/kavishdevar/librepods/utils/CasePopupPolicy.kt` (novo)
- `android/app/src/main/java/me/kavishdevar/librepods/utils/PopupWindow.kt`
- `android/app/src/main/java/me/kavishdevar/librepods/utils/Packets.kt`
- `android/app/src/main/java/me/kavishdevar/librepods/services/AirPodsService.kt`
- `android/app/src/main/java/me/kavishdevar/librepods/screens/AppSettingsScreen.kt`
- `android/app/src/main/java/me/kavishdevar/librepods/screens/Onboarding.kt`
- `android/app/src/main/java/me/kavishdevar/librepods/utils/RootlessDiagnostics.kt`
- `android/app/src/main/res/layout/popup_window.xml`
- `android/app/src/main/res/drawable/popup_m51_background.xml` (novo)

## Validação e limites

- Política de disparo testada com Kotlin/JVM (7 cenários: opt-in, pareamento, modelo, tampa, distância, sucesso e cooldown).
- Quatro testes de diagnóstico anteriores continuam passando; verificador estrutural do fork v4 passou.
- XMLs validados por parser XML; IDs do layout usados pelo popup verificados.
- APK não compilado localmente: o Gradle Wrapper requer download de `gradle-8.11.1-bin.zip` e este ambiente não tem acesso a `services.gradle.org`.
- Nenhum teste físico foi realizado com Samsung M51/AirPods Pro 3. Não há comprovação de que o firmware dos fones divulga os campos BLE esperados neste telefone.
- Para compilar no Android Studio: abrir a pasta `android`, instalar JDK 17, SDK 35, executar `./gradlew assembleDebug` com internet. Também há workflow GitHub Actions no repositório.
