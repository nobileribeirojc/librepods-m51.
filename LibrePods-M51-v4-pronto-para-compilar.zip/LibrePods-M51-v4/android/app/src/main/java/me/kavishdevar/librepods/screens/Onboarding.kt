// AGPL-3.0: experimental rootless entry point in the original LibrePods.
package me.kavishdevar.librepods.screens
import kotlin.io.encoding.ExperimentalEncodingApi
import android.Manifest
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import me.kavishdevar.librepods.services.ServiceManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import me.kavishdevar.librepods.utils.RootlessDiagnostics
import me.kavishdevar.librepods.utils.BLEManager
@OptIn(ExperimentalEncodingApi::class)
@Composable
fun Onboarding(navController: NavController, activityContext: Context) {
 var revision by remember { mutableIntStateOf(0) }
 var selectedDevice by remember { mutableStateOf<BluetoothDevice?>(null) }
 val hasConnectPermission = ContextCompat.checkSelfPermission(
     activityContext, Manifest.permission.BLUETOOTH_CONNECT
 ) == PackageManager.PERMISSION_GRANTED
 val pairedAirPods = remember(revision, hasConnectPermission) {
     if (!hasConnectPermission) emptyList() else try {
         val adapter = activityContext.getSystemService(BluetoothManager::class.java)?.adapter
         adapter?.bondedDevices?.sortedWith(compareBy<BluetoothDevice> {
             if (it.name?.contains("AirPods", ignoreCase = true) == true) 0 else 1
         }.thenBy { it.name.orEmpty() }) ?: emptyList()
     } catch (e: SecurityException) {
         RootlessDiagnostics.fail("Listagem dos dispositivos pareados", e)
         emptyList()
     }
 }
 LaunchedEffect(Unit) { while (true) { delay(1000); revision++ } }
 val report = remember(revision) { RootlessDiagnostics.report() }
 Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
  Text("LibrePods · Diagnóstico M51", style = MaterialTheme.typography.headlineMedium)
  Text("Adaptação experimental do LibrePods 0.1.0-rc.4. A conexão de controle no Android 12 pode falhar por uma limitação do sistema. Nenhuma correção de sistema foi aplicada.")
  Text("1. Ative Bluetooth e Localização e pareie os AirPods.\n2. Abra o estojo perto do celular.\n3. Confira o diagnóstico e selecione o dispositivo anunciado.")
  Button(onClick = { activityContext.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }) { Text("Abrir Bluetooth") }
  Button(onClick = { activityContext.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }) { Text("Abrir Localização") }
  Text("Teste de conexão AACP clássico (sem root)", style = MaterialTheme.typography.titleMedium)
  Text("Este teste usa o serviço original do LibrePods, não um protocolo substituto. " +
       "É necessário conectar os AirPods pelo Bluetooth do Android antes de tentar. " +
       "O resultado não altera o sistema ou instala módulos de root.")
  if (!hasConnectPermission) {
      Text("Permissão BLUETOOTH_CONNECT não concedida. Volte à tela principal e autorize Bluetooth.")
  } else if (pairedAirPods.isEmpty()) {
      Text("Nenhum dispositivo Bluetooth pareado encontrado. Pareie os AirPods nas " +
           "configurações do Android e retorne a esta tela.")
  } else {
      Text("Escolha os AirPods entre os dispositivos pareados (inclusive se você mudou o nome):")
      pairedAirPods.forEach { candidate ->
          OutlinedButton(onClick = { selectedDevice = candidate }) {
              Text("${candidate.name ?: "AirPods"}${if (candidate == selectedDevice) " · selecionado" else ""}")
          }
      }
      Button(enabled = selectedDevice != null, onClick = {
          val target = selectedDevice
          if (target != null) {
              val service = ServiceManager.getService()
              if (service == null) {
                  RootlessDiagnostics.stage("Serviço original do LibrePods ainda não iniciado. " +
                      "Volte à tela principal e reabra o diagnóstico.")
              } else {
                  RootlessDiagnostics.stage("Teste solicitado; verificando L2CAP em segundo plano")
                  CoroutineScope(Dispatchers.IO).launch {
                      try { service.connectToSocket(target) }
                      catch (e: Exception) { RootlessDiagnostics.fail("Teste manual", e) }
                  }
              }
          }
      }) { Text("Testar conexão dos AirPods") }
  }
  Text("Se o teste falhar, compartilhe o relatório abaixo. Não mostra endereço Bluetooth, " +
       "chaves nem conteúdo dos pacotes.")
  Text(report)
  val candidates = remember(revision) { RootlessDiagnostics.devices() }
  candidates.forEach { item -> OutlinedButton(onClick = { RootlessDiagnostics.selected = item.first; revision++ }) { Text(item.second) } }
  Text("Prévia da janela AirPods", style = MaterialTheme.typography.titleMedium)
  Text("Ative 'Exibir sobre outros apps' para ver a janela. A bateria só aparece quando " +
       "houver leitura BLE recente; valores desconhecidos ficam como —.")
  OutlinedButton(onClick = {
      activityContext.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
          Uri.parse("package:${activityContext.packageName}")))
  }) { Text("Autorizar janela sobre outros apps") }
  Button(onClick = {
      val service = ServiceManager.getService()
      if (service != null) {
          val s = RootlessDiagnostics.selectedStatus()
              ?: BLEManager.AirPodsStatus(address = "", model = "AirPods Pro 3")
          service.showPopup(service, "AirPods Pro 3", bleStatus = s, unverified = true)
      }
  }) { Text("Visualizar janela com a bateria disponível") }
  Button(onClick = { navController.popBackStack() }) { Text("Voltar ao LibrePods") }
  OutlinedButton(onClick = {
   val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, report) }
   activityContext.startActivity(Intent.createChooser(send, "Compartilhar diagnóstico"))
  }) { Text("Compartilhar este diagnóstico") }
  Text("Bateria BLE e conexão de controle são independentes. A interface original só controla os fones se a comunicação funcionar. Versão ainda não testada fisicamente no M51.")
 }
}
