/*
 * LibrePods-M51 BLE/L2CAP diagnostics — AGPL-3.0-or-later.
 * This is an addition to the LibrePods original Android app, not a separate app.
 */
package me.kavishdevar.librepods.utils

import android.os.SystemClock
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

object RootlessDiagnostics {
    private const val FRESH_MS = 15_000L
    private const val PRUNE_MS = 60_000L
    private const val MAX_CANDIDATES = 30

    val total = AtomicInteger()
    val apple = AtomicInteger()
    val proximity = AtomicInteger()
    val controlPackets = AtomicInteger()
    val connectionAttempts = AtomicInteger()
    val connectedAttempts = AtomicInteger()

    @Volatile var controlStage = "Ainda não houve tentativa"
    @Volatile var failureCategory = "Não determinado"
    @Volatile var connectDurationMs: Long? = null
    @Volatile private var startedAt: Long = 0L

    @Synchronized fun beginConnection() {
        connectionAttempts.incrementAndGet()
        startedAt = SystemClock.elapsedRealtime()
        connectDurationMs = null
        failureCategory = "Aguardando resultado"
        controlStage = "Verificação inicial"
        controlStatus = "Iniciando tentativa L2CAP clássica (AACP, PSM 4097)"
    }

    @Synchronized fun stage(value: String) {
        controlStage = value
        controlStatus = value
    }

    @Synchronized fun connected() {
        connectedAttempts.incrementAndGet()
        connectDurationMs = (SystemClock.elapsedRealtime() - startedAt).takeIf { startedAt > 0 }
        failureCategory = "Nenhuma: L2CAP estabelecido"
        controlStage = "Conexão estabelecida"
        controlStatus = "L2CAP conectado; aguardando pacotes AACP"
    }

    private fun classify(error: Throwable): String {
        val summary = generateSequence(error) { it.cause }
            .take(5)
            .joinToString(" ") { "${it.javaClass.simpleName} ${it.message.orEmpty()}" }
            .lowercase(Locale.ROOT)
        return when {
            "bluetooth_privileged" in summary || "permission denial" in summary ||
                "securityexception" in summary || "requires bluetooth" in summary ->
                "Permissão recusada pelo Android / permissão privilegiada"
            "no psm" in summary || "psm not" in summary ->
                "Canal PSM indisponível na pilha Bluetooth"
            "no matching constructor" in summary || "nosuchmethod" in summary ||
                "failed to create bluetoothsocket" in summary ->
                "Construtor BluetoothSocket incompatível com esta versão"
            "timeout" in summary || "timed out" in summary || "socket closed" in summary ->
                "Tempo esgotado / negociação L2CAP não concluída"
            "connection refused" in summary || "connection rejected" in summary ->
                "Conexão rejeitada pelo periférico ou pela pilha"
            "bluetooth off" in summary -> "Bluetooth desligado"
            else -> "Erro ainda não identificado (consultar logcat técnico)"
        }
    }


    @Volatile var scanStatus = "Aguardando scanner"
    @Volatile var controlStatus = "Conexão de controle ainda não testada"
    // Used only as an internal map key, never exported.
    @Volatile var selected: String? = null

    private data class Candidate(val status: BLEManager.AirPodsStatus, val seenAt: Long)
    private val candidates = linkedMapOf<String, Candidate>()

    @Synchronized fun fail(stage: String, error: Throwable) {
        controlStage = stage
        failureCategory = classify(error)
        connectDurationMs = (SystemClock.elapsedRealtime() - startedAt).takeIf { startedAt > 0 }
        // Never export device addresses, Bluetooth keys or raw packets.
        val redacted = (error.message ?: "Sem detalhe")
            .replace(Regex("(?i)(?:[0-9a-f]{2}:){5}[0-9a-f]{2}"), "[endereço omitido]")
            .replace(Regex("(?i)[0-9a-f]{12}"), "[identificador omitido]")
            .replace('\n', ' ')
            .take(200)
        controlStatus = "$stage: ${error.javaClass.simpleName}: $redacted"
    }

    @Synchronized private fun prune(now: Long = SystemClock.elapsedRealtime()) {
        val expired = candidates.filterValues { now - it.seenAt > PRUNE_MS }.keys
        for (key in expired) candidates.remove(key)
        while (candidates.size > MAX_CANDIDATES) {
            val oldestKey = candidates.minByOrNull { it.value.seenAt }?.key ?: break
            candidates.remove(oldestKey)
        }
        val selection = selected
        if (selection != null && !candidates.containsKey(selection)) selected = null
    }

    @Synchronized fun observe(status: BLEManager.AirPodsStatus) {
        val now = SystemClock.elapsedRealtime()
        // Update first, evict old rotating addresses second; otherwise the list locks at 30.
        candidates[status.address] = Candidate(status, now)
        prune(now)
    }

    @Synchronized fun devices(): List<Pair<String, String>> {
        val now = SystemClock.elapsedRealtime()
        prune(now)
        return candidates.values
            .filter { now - it.seenAt <= FRESH_MS }
            .sortedByDescending { it.seenAt }
            .mapIndexed { index, item -> item.status.address to
                "${item.status.model} · anúncio recente ${index + 1}" }
    }

    /** Fresh selected public BLE candidate; identity is NOT cryptographically authenticated. */
    @Synchronized fun selectedStatus(): BLEManager.AirPodsStatus? {
        prune()
        val candidate = candidates[selected] ?: return null
        if (SystemClock.elapsedRealtime() - candidate.seenAt > FRESH_MS) return null
        return candidate.status
    }

    @Synchronized fun battery(): String {
        prune()
        val candidate = candidates[selected] ?: return "Selecione um anúncio recente dos AirPods."
        if (SystemClock.elapsedRealtime() - candidate.seenAt > FRESH_MS)
            return "Leitura antiga. Abra o estojo novamente para atualizar."
        fun value(n: Int?): String = if (n == null) "—" else "≈ ${n.coerceIn(0, 100)}%"
        val s = candidate.status
        return "Esquerdo: ${value(s.leftBattery)}\n" +
            "Direito: ${value(s.rightBattery)}\n" +
            "Estojo: ${value(s.caseBattery)}\n" +
            "Bateria aproximada (passos de 10%). BLE não comprova identidade ou controle."
    }

    fun report(): String = """LibrePods · experimento Galaxy M51 (base v0.1.0-rc.4)
Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT}); ${android.os.Build.MODEL}
Patch de segurança: ${android.os.Build.VERSION.SECURITY_PATCH}
$scanStatus
Anúncios BLE: ${total.get()}
Anúncios Apple: ${apple.get()}
Mensagens de proximidade: ${proximity.get()}
Etapa: $controlStage
Tentativas de L2CAP: ${connectionAttempts.get()}
L2CAP conectado: ${connectedAttempts.get()}
Duração da última tentativa: ${connectDurationMs?.let { "$it ms" } ?: "não medida"}
Classificação: $failureCategory
$controlStatus
Nota: o Android oferece L2CAP público apenas por Bluetooth LE. AACP usa L2CAP clássico;
a conexão atual ainda depende de código herdado do LibrePods e da pilha Bluetooth do fabricante.
Pacotes de controle recebidos: ${controlPackets.get()}
${battery()}
Sem MAC, chaves ou pacotes brutos neste relatório.
""".trimIndent()
}
