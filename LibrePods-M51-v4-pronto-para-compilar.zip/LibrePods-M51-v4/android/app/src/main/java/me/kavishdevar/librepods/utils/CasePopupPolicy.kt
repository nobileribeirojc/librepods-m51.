/* LibrePods original fork - Galaxy M51 experimental popup; AGPL-3.0-or-later. */
package me.kavishdevar.librepods.utils

/** Gate for public (unverified) BLE events.  No cryptographic device identity is implied. */
internal class CasePopupPolicy(
    private val minimumRssiDbm: Int = -64,
    private val cooldownMs: Long = 60_000L
) {
    private var lastPopupAtMs: Long? = null

    fun canShow(
        model: String,
        lidOpen: Boolean,
        rssiDbm: Int,
        explicitlyEnabled: Boolean,
        hasBondedAirPods: Boolean,
        nowMs: Long
    ): Boolean {
        if (!explicitlyEnabled || !hasBondedAirPods || model != "AirPods Pro 3") return false
        if (!lidOpen || rssiDbm < minimumRssiDbm) return false
        val last = lastPopupAtMs
        return last == null || nowMs - last >= cooldownMs
    }

    fun onShown(nowMs: Long) { lastPopupAtMs = nowMs }
}
