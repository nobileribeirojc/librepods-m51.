/* LibrePods - AGPL-3.0-or-later; M51 popup upgrades to the original window. */
package me.kavishdevar.librepods.utils

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.ImageButton
import android.widget.TextView
import me.kavishdevar.librepods.R

class PopupWindow(private val context: Context, private val onCloseCallback: () -> Unit = {}) {
    private val manager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val view: View = (context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater)
        .inflate(R.layout.popup_window, null)
    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_DIM_BEHIND,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.BOTTOM; dimAmount = 0.12f }
    private var closing = false
    private var receiver: BroadcastReceiver? = null
    private var dismissTask: Runnable? = null
    private var sourceIsBle = false

    init {
        view.findViewById<ImageButton>(R.id.close_button).setOnClickListener { close() }
    }

    @SuppressLint("SetTextI18n")
    fun open(
        name: String,
        batteryNotification: AirPodsNotifications.BatteryNotification,
        bleStatus: BLEManager.AirPodsStatus? = null,
        unverified: Boolean = false
    ): Boolean {
        if (view.parent != null || closing) return false
        return try {
            view.findViewById<TextView>(R.id.name).text = name
            sourceIsBle = bleStatus != null
            if (bleStatus != null) updateBle(bleStatus, unverified)
            else updateAacp(batteryNotification.getBattery())

            manager.addView(view, params)
            view.translationY = context.resources.displayMetrics.heightPixels.toFloat()
            view.animate().translationY(0f).setDuration(330L)
                .setInterpolator(DecelerateInterpolator()).start()
            if (!sourceIsBle) registerBatteryUpdates()
            dismissTask = Runnable { close() }.also { handler.postDelayed(it, 11_000L) }
            true
        } catch (t: Throwable) {
            Log.e("LibrePodsPopup", "Cannot open popup", t)
            if (view.parent != null) try { manager.removeViewImmediate(view) } catch (_: Exception) {}
            unregisterBatteryUpdates()
            onCloseCallback()
            false
        }
    }

    fun updateBle(status: BLEManager.AirPodsStatus, unverified: Boolean) {
        if (!sourceIsBle && view.parent != null) return
        batteryValue(R.id.left_battery, R.id.left_charging, status.leftBattery, status.isLeftCharging)
        batteryValue(R.id.right_battery, R.id.right_charging, status.rightBattery, status.isRightCharging)
        batteryValue(R.id.case_battery, R.id.case_charging, status.caseBattery, status.isCaseCharging)
        view.findViewById<TextView>(R.id.battery_source_note).text =
            if (unverified) "≈ BLE público · dispositivo próximo não autenticado · imagem ilustrativa"
            else "≈ Bateria via BLE · imagem ilustrativa dos AirPods"
    }

    private fun updateAacp(batteries: List<Battery>) {
        fun from(component: Int): Battery? = batteries.find { it.component == component }
        fun value(component: Int, textId: Int, chargingId: Int) {
            val b = from(component)
            batteryValue(textId, chargingId,
                if (b == null || b.status == BatteryStatus.DISCONNECTED) null else b.level,
                b?.status == BatteryStatus.CHARGING)
        }
        value(BatteryComponent.LEFT, R.id.left_battery, R.id.left_charging)
        value(BatteryComponent.RIGHT, R.id.right_battery, R.id.right_charging)
        value(BatteryComponent.CASE, R.id.case_battery, R.id.case_charging)
        view.findViewById<TextView>(R.id.battery_source_note).text =
            "Bateria via protocolo AACP · imagem ilustrativa dos AirPods"
    }

    private fun batteryValue(textId: Int, chargingId: Int, level: Int?, charging: Boolean) {
        view.findViewById<TextView>(textId).text = level?.takeIf { it in 0..100 }
            ?.let { "$it%" } ?: "—"
        view.findViewById<TextView>(chargingId).text =
            if (level != null && charging) "Carregando" else ""
    }

    private fun registerBatteryUpdates() {
        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action != AirPodsNotifications.BATTERY_DATA || sourceIsBle) return
                @Suppress("DEPRECATION")
                val values = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableArrayListExtra("data", Battery::class.java)
                else intent.getParcelableArrayListExtra<Battery>("data")
                if (values != null) updateAacp(values)
            }
        }
        val filter = IntentFilter(AirPodsNotifications.BATTERY_DATA)
        if (Build.VERSION.SDK_INT >= 33)
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else context.registerReceiver(receiver, filter)
    }

    private fun unregisterBatteryUpdates() {
        receiver?.let { try { context.unregisterReceiver(it) } catch (_: Exception) {} }
        receiver = null
    }

    fun close() {
        if (closing) return
        closing = true
        dismissTask?.let { handler.removeCallbacks(it) }
        dismissTask = null
        unregisterBatteryUpdates()
        if (view.parent == null) { closing = false; onCloseCallback(); return }
        ObjectAnimator.ofFloat(view, View.TRANSLATION_Y, view.height.toFloat()).apply {
            duration = 230L
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    try { if (view.parent != null) manager.removeViewImmediate(view) }
                    catch (e: Exception) { Log.w("LibrePodsPopup", "Remove failed", e) }
                    finally { closing = false; onCloseCallback() }
                }
            })
            start()
        }
    }
    val isShowing: Boolean get() = view.parent != null && !closing
}
