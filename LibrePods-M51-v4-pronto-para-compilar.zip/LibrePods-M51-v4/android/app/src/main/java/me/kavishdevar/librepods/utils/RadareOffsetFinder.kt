// AGPL-3.0: root-dependent functions disabled in this fork.
package me.kavishdevar.librepods.utils
import android.content.Context
class RadareOffsetFinder(context: Context) {
 fun isHookOffsetAvailable() = false
 companion object { fun clearHookOffsets() = false; fun findBluetoothLibraryPath(): String? = null }
}
