package me.kavishdevar.librepods.utils

fun main() {
    val gate = CasePopupPolicy()
    fun eligible(model: String = "AirPods Pro 3", lid: Boolean = true,
                 rssi: Int = -51, enabled: Boolean = true, paired: Boolean = true,
                 at: Long = 100_000L): Boolean =
        gate.canShow(model, lid, rssi, enabled, paired, at)
    check(!eligible(enabled = false)) { "Should require opt-in" }
    check(!eligible(paired = false)) { "Should require paired AirPods" }
    check(!eligible(model = "AirPods 4")) { "M51 Pro3 model only" }
    check(!eligible(lid = false)) { "Only case-open advertisements" }
    check(!eligible(rssi = -90)) { "Ignore distant advertisements" }
    check(eligible()) { "Accept permitted open, near, bonded Pro3" }
    gate.onShown(100_000L)
    check(!eligible(at = 101_000L)) { "Throttle repeated ads" }
    check(eligible(at = 160_000L)) { "Allow later reopen" }
    println("7 tests passed: opt-in, bonded, model, lid, signal, success, cooldown")
}
