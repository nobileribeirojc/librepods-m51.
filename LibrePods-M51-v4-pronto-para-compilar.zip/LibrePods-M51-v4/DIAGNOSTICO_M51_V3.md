# LibrePods original para Galaxy M51 — continuação v3

Esta pasta deriva do **LibrePods original v0.1.0-rc.4**, mantendo o app, interface,
AACPManger, ATTManager e seus comandos; o identificador da variante de teste é
`me.kavishdevar.librepods.m51test`. Código AGPLv3.

## O que foi implementado nesta continuação

- Tela adicional de diagnóstico acessível pelo menu existente do LibrePods;
- seleção de qualquer aparelho Bluetooth pareado, mesmo se os AirPods forem renomeados;
- botão **Testar conexão dos AirPods**, que solicita a comunicação AACP original
  sem executar o bloqueio de `socket.connect()` no thread de interface;
- diagnóstico de etapas (construtor oculto, negociação L2CAP clássico PSM 4097,
  handshake AACP), duração, quantidade de tentativas e motivo provável;
- proteção contra tentativas L2CAP simultâneas, e espera mínima de 30 segundos
  entre reconexões automáticas originadas por anúncios BLE desconectados;
- remoção de dois estados de conexão falsos: conexão só é confirmada depois
  do sucesso do socket; não tratamos anúncio BLE como conexão AACP;
- evita tentar endereços inválidos/rotativos na conexão clássica;
- mantém scanner BLE e dados aproximados de bateria, sem exigir root;
- chamadas a `BluetoothDevice#setMetadata`, reservadas ao sistema, são
  desativadas nesta versão experimental sem root, sem alterar o AACP.

## Por que não prometer ANC no Android 12

`BluetoothDevice.createL2capChannel(PSM)` é API pública, mas funciona exclusivamente
com Bluetooth **LE**. O AACP usa um canal L2CAP **clássico**, PSM `4097`. O LibrePods
usa um construtor interno de BluetoothSocket para isso. A negociação L2CAP depende
do firmware/pilha Bluetooth do dispositivo. Problema upstream foi corrigido em builds
recentes do Android; a correção não é garantida no Android 12/One UI do M51.

O diagnóstico classifica alguns erros conhecidos, mas a confirmação exige instalar
e executar uma build no aparelho físico. Nenhuma alteração de firmware, root,
exploração de vulnerabilidades ou bypass de permissões privilegiadas é oferecida.

## Como gerar APK pelo GitHub Actions

1. Crie um repositório pessoal **privado ou público** no GitHub.
2. Envie **todo o conteúdo desta pasta** para a raiz do repositório.
3. Abra a aba `Actions` > `Build LibrePods M51 debug APK` > `Run workflow`.
4. A execução bem-sucedida gera artefato `librepods-m51-debug-apk` contendo
   `app-debug.apk`. Instale a build de teste no Galaxy M51.
5. Dê permissão de Bluetooth/Localização ao abrir o LibrePods, e conecte seus
   AirPods Pro 3 pelo Bluetooth do Android.
6. Na tela original, entre em **Bateria BLE e diagnóstico**; selecione o par
   pareado e toque **Testar conexão dos AirPods**. Aguarde 5 a 10 segundos.
7. Compartilhe o relatório de diagnóstico (sem MAC ou chaves) para definir
   o próximo ajuste no código, com base na falha real.

**Compilação local:** JDK 17, SDK Android 35 e Gradle 8.11.1. Execute
`cd android && ./gradlew :app:assembleDebug`.

## Verificações realizadas neste ambiente

- `RootlessDiagnostics.kt` compilou com o compilador Kotlin/JVM e stubs Android
  de teste; quatro cenários passaram: permissão, PSM, sucesso, redaction BLE.
- Não houve compilação Android completa, porque este ambiente não consegue
  acessar `services.gradle.org` para obter o Gradle Wrapper.
- Não houve teste físico no SM-M515F ou AirPods Pro 3.

**Este ZIP é código-fonte, NÃO um APK compilado nem uma promessa de ANC/Transparência.**

Fontes: https://github.com/librepods-org/librepods/blob/main/android/README.md
; https://github.com/d4rken-org/capod/issues/538
; https://developer.android.com/reference/android/bluetooth/BluetoothDevice#createL2capChannel(int)
