# Adaptação experimental do LibrePods para M51 sem root

Base: LibrePods v0.1.0-rc.4, commit b8e9765. Esta versão anterior já admite
Android 12. Mantém a interface de configurações e o código AACP originais.
O pacote usa um identificador distinto, me.kavishdevar.librepods.m51test,
e o nome LP M51 Experimental para não se passar pela distribuição oficial.

## Alterações

- Android mínimo 12, SDK de compilação 35.
- Permissão de notificação solicitada apenas no Android 13 ou superior.
- Localização precisa/aproximada incluída para a busca BLE no Android 12;
  retirada a declaração neverForLocation, que pode filtrar anúncios.
- Varredura sem filtro de hardware e sem lote: os filtros são aplicados no código.
- Contagem separada de anúncios BLE, anúncios da Apple, mensagens de proximidade
  e respostas pela conexão de controle.
- Modelo anunciado 0x2720 identificado como AirPods Pro 3 (referência: CAPod).
- Leitura pública de bateria, com escolha explícita do dispositivo, antes da
  verificação IRK. Essa leitura aparece apenas no diagnóstico e não é tratada
  como identidade autenticada nem aciona os automatismos do app.
- Leituras públicas com mais de 15 segundos são ocultadas.
- Removidos o carregamento do módulo nativo/Xposed e as chamadas su; configuração
  de root substituída por uma tela de teste. Funções privilegiadas retornam indisponível.
- Conexão L2CAP original mantida, com fechamento por temporizador após 4 segundos
  para evitar uma espera indefinida em socket.connect().
- O diagnóstico compartilhável não inclui MAC, chaves IRK/ENC ou pacotes brutos.

## Limitação central

Esta adaptação NÃO corrige a pilha Bluetooth do Android. A negociação L2CAP pode
continuar falhando no M51. Não há promessa de cancelamento de ruído/Transparência
funcionais. Dados BLE de bateria não comprovam que a conexão de controle funciona.
Os controles da interface original só podem atuar se a conexão real for estabelecida.

Não foi feita engenharia reversa de um binário da Apple nesta entrega.
O projeto aproveita a implementação do protocolo já existente no LibrePods.
Não há aparelho M51/AirPods físico conectado ao ambiente de desenvolvimento.

## Compilação

JDK 17, Gradle Wrapper 8.11.1, Android SDK 35 e Build Tools 35.0.0.
Dentro de android: ./gradlew assembleDebug
Saída: android/app/build/outputs/apk/debug/app-debug.apk.
O download de dependências Google Maven/Maven Central é necessário na primeira vez.
Não há necessidade de NDK nesta variante sem hooks nativos.

## Teste no aparelho, quando houver APK compilado

1. Ative Bluetooth e Localização e pareie os AirPods pelo Android.
2. Abra o app e conceda as permissões exibidas; sobreposição é opcional.
3. Abra o estojo perto do telefone e observe os contadores na tela de diagnóstico.
4. Se houver dispositivos anunciados, selecione o seu para ver a bateria aproximada.
5. Abra a interface original para verificar a conexão de controle.
6. Reabra o app ou use a opção de solução de problemas para retornar ao diagnóstico.
7. Compartilhe somente esse diagnóstico resumido ou um print dele.

## Licença e proveniência

A base desta versão é GNU AGPL v3; veja LICENSE e cabeçalhos originais.
As alterações deste experimento são disponibilizadas sob os mesmos termos.
https://github.com/librepods-org/librepods/tree/v0.1.0-rc.4
Não é uma versão oficial do LibrePods e não é afiliada a Apple ou Samsung.
