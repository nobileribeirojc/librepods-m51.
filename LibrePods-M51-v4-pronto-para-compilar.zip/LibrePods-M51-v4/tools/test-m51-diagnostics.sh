#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE="$HERE/../android/app/src/main/java/me/kavishdevar/librepods/utils/RootlessDiagnostics.kt"
TEST="$HERE/m51-smoke-test-stubs"
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
kotlinc "$SOURCE" "$TEST/android/os/Build.kt" "$TEST/android/os/SystemClock.kt" \
  "$TEST/me/kavishdevar/librepods/utils/BLEManager.kt" "$TEST/TestM51.kt" \
  -include-runtime -d "$TEMP/tests.jar"
java -jar "$TEMP/tests.jar"
