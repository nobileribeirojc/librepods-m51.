import me.kavishdevar.librepods.utils.RootlessDiagnostics
import me.kavishdevar.librepods.utils.BLEManager
fun main() {
    val d=RootlessDiagnostics
    d.beginConnection()
    d.stage("Testando o canal")
    d.fail("Conexão L2CAP", SecurityException("Need BLUETOOTH_PRIVILEGED for AA:BB:CC:DD:EE:FF"))
    val report=d.report()
    require(report.contains("Permissão recusada"))
    require(report.contains("[endereço omitido]"))
    require(!report.contains("AA:BB:CC:DD:EE:FF"))
    require(report.contains("Tentativas de L2CAP: 1"))
    println("TESTE 1 OK: falha de permissão + remoção de MAC + contador")
    d.beginConnection()
    d.fail("Conexão L2CAP", java.io.IOException("No PSM available"))
    require(d.report().contains("Canal PSM indisponível"))
    println("TESTE 2 OK: classificação de PSM")
    d.beginConnection()
    d.connected()
    require(d.report().contains("L2CAP conectado: 1"))
    println("TESTE 3 OK: sucesso medido")
    d.observe(BLEManager.AirPodsStatus("01:02:03:04:05:06",leftBattery=80,rightBattery=70,caseBattery=50))
    d.selected="01:02:03:04:05:06"
    require(d.report().contains("Esquerdo: ≈ 80%"))
    require(!d.report().contains("01:02:03:04:05:06"))
    println("TESTE 4 OK: bateria e relatório sem MAC")
}
