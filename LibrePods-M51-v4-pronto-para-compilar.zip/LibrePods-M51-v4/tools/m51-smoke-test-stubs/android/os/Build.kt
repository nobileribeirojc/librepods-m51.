package android.os
object Build { object VERSION { const val RELEASE = "12"; const val SDK_INT = 31; const val SECURITY_PATCH = "2022-10-01" }; const val MODEL = "SM-M515F" }
