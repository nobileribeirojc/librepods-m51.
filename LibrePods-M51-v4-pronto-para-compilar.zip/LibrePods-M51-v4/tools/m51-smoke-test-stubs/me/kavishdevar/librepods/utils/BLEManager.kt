package me.kavishdevar.librepods.utils
class BLEManager { data class AirPodsStatus(val address: String, val model:String="AirPods Pro 3", val leftBattery:Int?=null,val rightBattery:Int?=null,val caseBattery:Int?=null) }
