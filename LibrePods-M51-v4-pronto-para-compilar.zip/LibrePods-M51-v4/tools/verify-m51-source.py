#!/usr/bin/env python3
"""Basic structural tests for the original LibrePods M51 fork. NOT an Android build."""
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "android/app"
MAIN = APP / "src/main"
NS = "{http://schemas.android.com/apk/res/android}"
for f in MAIN.rglob("*.xml"):
    ET.parse(f)
manifest = ET.parse(MAIN / "AndroidManifest.xml").getroot()
main_activity = manifest.find("./application/activity[@" + NS + "name='.MainActivity']")
assert main_activity is not None
activities = manifest.findall("./application/activity")
launchers = []
for activity in activities:
    for filter_ in activity.findall("intent-filter"):
        categories = [x.attrib.get(NS + "name") for x in filter_.findall("category")]
        if "android.intent.category.LAUNCHER" in categories:
            launchers.append(activity.attrib.get(NS + "name"))
assert launchers == [".MainActivity"], launchers
app = (APP / "build.gradle.kts").read_text()
assert "minSdk = 31" in app
assert 'versionName = "0.1.0-rc.4-m51-exp4-popup"' in app
source = (MAIN / "java/me/kavishdevar/librepods").resolve()
main_code = (source / "MainActivity.kt").read_text()
assert 'startDestination = "settings"' in main_code
assert 'composable("m51_diagnostics")' in main_code
assert 'composable("troubleshooting")' in main_code
assert 'TroubleshootingScreen(navController)' in main_code
assert '"android.permission.BLUETOOTH_CONNECT"' in main_code
assert '"android.permission.BLUETOOTH_SCAN"' in main_code
assert '"android.permission.ACCESS_FINE_LOCATION"' in main_code
assert (source / "utils/AACPManager.kt").exists(), "Original protocol engine missing"
assert (source / "utils/BLEManager.kt").exists(), "Original BLE manager missing"
service_code = (source / "services/AirPodsService.kt").read_text()
assert 'RootlessDiagnostics.beginConnection()' in service_code
assert 'l2capAttemptRunning.compareAndSet(false, true)' in service_code
assert 'RootlessDiagnostics.connected()' in service_code
assert 'isConnectedLocally = true' in service_code
assert 'Testar conexão dos AirPods' in (source / "screens/Onboarding.kt").read_text()
assert (source / "services/AirPodsService.kt").exists(), "Original service missing"
assert 'onNearbyProximityAdvertisement' in service_code
assert 'm51_nearby_popup_opt_in' in service_code
assert 'setBatteryFromBle' in (source / "utils/Packets.kt").read_text()
assert (source / "utils/CasePopupPolicy.kt").exists()
popup_xml = (MAIN / "res/layout/popup_window.xml").read_text()
for id_ in ('left_battery', 'right_battery', 'case_battery', 'airpods_image', 'battery_source_note'):
    assert '@+id/' + id_ in popup_xml
assert 'Visualizar janela com a bateria disponível' in (source / "screens/Onboarding.kt").read_text()
print("PASS: XML, Android 12 baseline, original LibrePods launcher/AACP, rootless BLE popup and battery display")
